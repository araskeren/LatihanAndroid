<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="">
            <div class="card">
                <div class="card-header">Daftar Toko | <a href="<?php echo e(route('toko.create')); ?>" class="btn btn-primary">TAMBAH TOKO</a></div>

                <div class="card-body">
                    <?php if(Auth::user()->level=='9'): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>LOGO</th>
                                <th>TOKO</th>
                                <th>ALAMAT TOKO</th>
                                <th>PEMILIK</th>
                                <th>NO TELP</th>
                                <th>EMAIL</th>
                                <th>ALAMAT PEMILIK</th>
                                <th>CREATED</th>
                                <th>UPDATE</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><img src="<?php echo e($i->gambar); ?>" alt="" class="gambar-preview"></td>
                                <td><?php echo e($i->nama_toko); ?></td>
                                <td><?php echo e($i->alamat_toko); ?></td>
                                <td><?php echo e($i->nama_pemilik); ?></td>
                                <td><?php echo e($i->no_telp); ?></td>
                                <td><?php echo e($i->email); ?></td>
                                <td><?php echo e($i->alamat_pemilik); ?></td>
                                <td><?php echo e($i->created_at); ?></td>
                                <td><?php echo e($i->updated_at); ?></td>
                                <td>
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item dropdown">
                                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                            <span class="caret"></span></a>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item" href="<?php echo e(route('barang.index',[
                                                'nama_toko'=>$i->nama_toko,'nama_pemilik'=>$i->nama_pemilik,'toko_id'=>$i->id])); ?>">PRODUK</a>
                                                <a class="dropdown-item" href="<?php echo e(route('toko.edit',[
                                                'toko_id'=>$i->id])); ?>">UBAH</a>
                                                <a class="dropdown-item" href="<?php echo e(route('toko.delete',[
                                                'toko_id'=>$i->id])); ?>">HAPUS</a>
                                            </div>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>