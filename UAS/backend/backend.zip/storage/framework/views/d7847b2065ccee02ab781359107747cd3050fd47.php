<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="">
            <div class="card">
                <div class="card-header">Daftar Transaksi</div>

                <div class="card-body">
                    <?php if(Auth::user()->level=='9'): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>TOKO</th>
                                <th>BARANG</th>
                                <th>HARGA</th>
                                <th>PEMBELI</th>
                                <th>NO TELP</th>
                                <th>ALAMAT</th>
                                <th>STATUS</th>
                                <th>KODE</th>
                                <th>CREATED</th>
                                <th>UPDATE</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i->nama_toko); ?></td>
                                <td><?php echo e($i->nama_barang); ?></td>
                                <td><?php echo e($i->harga); ?></td>
                                <td><?php echo e($i->nama_pembeli); ?></td>
                                <td><?php echo e($i->no_telp); ?></td>
                                <td><?php echo e($i->alamat); ?></td>
                                <td><?php echo e($i->status); ?></td>
                                <td><?php echo e($i->kode_pembayaran); ?></td>
                                <td><?php echo e($i->created_at); ?></td>
                                <td><?php echo e($i->updated_at); ?></td>
                                <td>
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item dropdown">
                                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                            <span class="caret"></span></a>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item" href="<?php echo e(route('transaksi.ubah.status',[
                                                'status'=>'pembayaran','id_transaksi'=>$i->id])); ?>">PEMBAYARAN</a>
                                                <a class="dropdown-item" href="<?php echo e(route('transaksi.ubah.status',[
                                                'status'=>'menunggu pengiriman','id_transaksi'=>$i->id])); ?>">MENUNGGU PENGIRIMAN</a>
                                                <a class="dropdown-item" href="<?php echo e(route('transaksi.ubah.status',[
                                                'status'=>'terkirim','id_transaksi'=>$i->id])); ?>">TERKIRIM</a>
                                                <a class="dropdown-item" href="<?php echo e(route('transaksi.ubah.status',[
                                                'status'=>'selesai','id_transaksi'=>$i->id])); ?>">SELESAI</a>
                                            </div>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>