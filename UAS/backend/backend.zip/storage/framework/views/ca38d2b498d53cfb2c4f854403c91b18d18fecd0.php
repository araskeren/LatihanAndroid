<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Daftar Barang | <?php echo e($nama_toko); ?> | Pemilik : <?php echo e($nama_pemilik); ?> | <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-primary">TAMBAH BARANG</a></div>

                <div class="card-body">
                    <?php if(Auth::user()->level=='9'): ?>
                    <table class="col-md-12">
                        <thead>
                            <tr>
                                <th>GAMBAR</th>
                                <th>BARANG</th>
                                <th>HARGA</th>
                                <th>DESKRIPSI</th>
                                <th>CREATED</th>
                                <th>UPDATE</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            
                                <td><img src="<?php echo e($i->gambar); ?>" alt="" class="gambar-preview"></td>
                                <td><?php echo e($i->nama); ?></td>
                                <td><?php echo e($i->harga); ?></td>
                                <td><?php echo e($i->deskripsi); ?></td>
                                <td><?php echo e($i->created_at); ?></td>
                                <td><?php echo e($i->updated_at); ?></td>
                                <td>
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item dropdown">
                                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                            <span class="caret"></span></a>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item" href="<?php echo e(route('barang.edit',[
                                                'barang_id'=>$i->id])); ?>">UBAH</a>
                                                <a class="dropdown-item" href="<?php echo e(route('barang.delete',[
                                                'barang_id'=>$i->id])); ?>">HAPUS</a>
                                            </div>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>